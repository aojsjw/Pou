MUSIC SETUP
===========
The UI expects the background track at:

    /client/audio/ghorob.mp3

Place your legally obtained/licensed copy of the song "غروب" here and keep
this exact filename: ghorob.mp3

Modern browsers may block audible autoplay. The panel starts the music after
a successful login (a user gesture), while the subscription page also has a
play button as a fallback.
